<?php
echo "Bigphoto bot";
?>